#ifndef RB_Aniamtion_V1
#define RB_Aniamtion_V1

#include "Arduino.h"
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

int eye_angry(int i, int pos); // pos = 1 also left or pos = 1 also rigth
int eye_bad(int i, int pos);
int eye_close(int i, int pos);
int eye_happy(int i, int pos);
int eye_incredible(int i, int pos);
int eye_sad(int i, int pos);
int eye_semi_happy(int i, int pos);
int eye_sleep(int i, int pos);

int mouth_hengry(int i);
int mouth_hengry_hot(int i);
int mouth_mischievous(int i);
int mouth_surprised(int i);